(function () {
  'use strict';
  const store = {
    get(key, fallback) {
      try {
        const v = localStorage.getItem(key);
        return v === null ? fallback : JSON.parse(v);
      } catch (e) { return fallback; }
    },
    set(key, value) {
      try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* ignore */ }
    }
  };
  function debounce(fn, wait) {
    let t;
    return function (...args) {
      clearTimeout(t);
      t = setTimeout(() => fn.apply(this, args), wait);
    };
  }

  function throttle(fn, wait) {
    let last = 0, timer = null;
    return function (...args) {
      const now = Date.now();
      const remaining = wait - (now - last);
      if (remaining <= 0) {
        last = now;
        fn.apply(this, args);
      } else if (!timer) {
        timer = setTimeout(() => {
          last = Date.now(); timer = null;
          fn.apply(this, args);
        }, remaining);
      }
    };
  }

  function el(tag, attrs, text) {
    const node = document.createElement(tag);
    if (attrs) for (const k in attrs) node.setAttribute(k, attrs[k]);
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function currentBreakpoint() {
    const w = window.innerWidth;
    if (w >= 1024) return 'десктоп';
    if (w >= 768) return 'планшет';
    return 'мобильный';
  }

  const toastArea = el('div', { class: 'toast-area', role: 'status', 'aria-live': 'polite' });
  document.body.appendChild(toastArea);

  function toast(message, type) {
    const t = el('div', { class: 'toast' + (type ? ' ' + type : '') }, message);
    toastArea.appendChild(t);
    while (toastArea.children.length > 3) toastArea.firstElementChild.remove();
    setTimeout(() => t.remove(), 3200);
  }

  const root = document.documentElement;
  const themeBtn = document.querySelector('.theme-toggle');

  function applyTheme(theme) {
    const dark = theme === 'dark';
    root.classList.toggle('theme-dark', dark);
    if (themeBtn) {
      themeBtn.textContent = dark ? '☀️' : '🌙';
      themeBtn.setAttribute('aria-label', dark ? 'Включить дневную тему' : 'Включить ночную тему');
      themeBtn.setAttribute('aria-pressed', String(dark));
    }
  }
  applyTheme(root.classList.contains('theme-dark') ? 'dark' : 'light');

  if (themeBtn) {
    themeBtn.addEventListener('click', () => {
      const next = root.classList.contains('theme-dark') ? 'light' : 'dark';
      applyTheme(next);
      store.set('zerno-theme', next);
      logEvent(next === 'dark' ? 'Включена ночная тема' : 'Включена дневная тема');
    });
  }

  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.getElementById('main-nav');

  function setMenu(open) {
    if (!nav || !navToggle) return;
    nav.classList.toggle('is-open', open);
    navToggle.setAttribute('aria-expanded', String(open));
    navToggle.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
    navToggle.textContent = open ? '✕' : '☰';
  }
  if (navToggle) {
    navToggle.addEventListener('click', () => setMenu(!nav.classList.contains('is-open')));
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && nav.classList.contains('is-open')) { setMenu(false); navToggle.focus(); }
    });
  }


  const stats = Object.assign(
    { clicks: 0, keys: 0, scrolls: 0, resizes: 0, likes: 0, cart: 0 },
    store.get('zerno-stats', {})
  );
  const labels = {
    clicks: 'Клики', keys: 'Нажатия клавиш', scrolls: 'Прокрутки (throttle)',
    resizes: 'Изменения окна (debounce)', likes: 'Лайки', cart: 'Добавлено в заказ'
  };


  const toggleBtn = el('button', {
    class: 'activity-toggle', type: 'button',
    'aria-expanded': 'false', 'aria-controls': 'activity-panel'
  });
  toggleBtn.append(el('span', { 'aria-hidden': 'true' }, '📊'), ' Активность: ');
  const totalOut = el('b', null, '0');
  toggleBtn.append(totalOut);

  const panel = el('section', { class: 'activity-panel', id: 'activity-panel', 'aria-label': 'Счётчик событий' });
  panel.hidden = true;
  panel.append(el('h2', null, 'Ваша активность'));
  const bpOut = el('p', { class: 'activity-bp' });
  panel.append(bpOut);

  const dl = el('dl', { class: 'activity-stats' });
  const outs = {};
  for (const key in labels) {
    dl.append(el('dt', null, labels[key]));
    outs[key] = el('dd', null, '0');
    dl.append(outs[key]);
  }
  panel.append(dl);
  const logList = el('ol', { class: 'activity-log', 'aria-label': 'Последние события' });
  panel.append(logList);
  const resetBtn = el('button', { class: 'icon-btn activity-reset', type: 'button' }, 'Сбросить счётчики');
  panel.append(resetBtn);

  document.body.append(panel, toggleBtn);


  let renderQueued = false;
  function render() {
    if (renderQueued) return;
    renderQueued = true;
    requestAnimationFrame(() => {
      renderQueued = false;
      let total = 0;
      for (const key in labels) {
        outs[key].textContent = stats[key];
        total += stats[key];
      }
      totalOut.textContent = total;
      bpOut.textContent = 'Ширина окна: ' + window.innerWidth + 'px — ' + currentBreakpoint();
    });
  }
  const save = debounce(() => store.set('zerno-stats', stats), 400);

  function bump(key) { stats[key]++; render(); save(); }

  const MAX_LOG = 8;
  function logEvent(message) {
    const li = el('li');
    const now = new Date();
    li.append(el('time', { datetime: now.toISOString() }, now.toLocaleTimeString('ru-RU')));
    li.append(document.createTextNode(message)); // текст пользователя — только как текст
    logList.prepend(li);
    while (logList.children.length > MAX_LOG) logList.lastElementChild.remove();
  }

  toggleBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    panel.hidden = !panel.hidden;
    toggleBtn.setAttribute('aria-expanded', String(!panel.hidden));
  });
  function closePanel() {
    panel.hidden = true;
    toggleBtn.setAttribute('aria-expanded', 'false');
  }
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !panel.hidden) closePanel(); });
  document.addEventListener('click', (e) => {
    if (!panel.hidden && !panel.contains(e.target) && !toggleBtn.contains(e.target)) closePanel();
  });
  resetBtn.addEventListener('click', () => {
    for (const key in stats) stats[key] = 0;
    logList.replaceChildren();
    store.set('zerno-stats', stats);
    render();
    toast('Счётчики сброшены');
  });


  const clickTimes = [];
  const CLICK_WINDOW = 3000, CLICK_LIMIT = 10;
  let lastClickWarn = 0;
  document.addEventListener('click', (e) => {
    if (panel.contains(e.target) || toggleBtn.contains(e.target)) return;
    bump('clicks');
    const target = e.target.closest('a, button');
    if (target) {
      const name = (target.getAttribute('aria-label') || target.textContent).trim().slice(0, 40);
      logEvent('Клик: ' + name);
    }
    const now = Date.now();
    clickTimes.push(now);
    while (clickTimes.length && now - clickTimes[0] > CLICK_WINDOW) clickTimes.shift();
    if (clickTimes.length >= CLICK_LIMIT && now - lastClickWarn > 5000) {
      lastClickWarn = now;
      toast('Высокая активность: ' + clickTimes.length + ' кликов за 3 секунды. Может, сначала кофе? ☕', 'warn');
      logEvent('Обнаружена высокая активность');
    }
  });

  document.addEventListener('keydown', () => bump('keys'));

  window.addEventListener('scroll', throttle(() => {
    bump('scrolls');
    toTop.classList.toggle('is-visible', window.scrollY > 400);
  }, 500), { passive: true });

  let lastBp = currentBreakpoint();
  window.addEventListener('resize', debounce(() => {
    bump('resizes');
    const bp = currentBreakpoint();
    if (bp !== lastBp) {
      logEvent('Брейкпоинт: ' + lastBp + ' → ' + bp);
      lastBp = bp;
      if (bp !== 'мобильный') setMenu(false);
    }
  }, 300));

  document.addEventListener('visibilitychange', () => {
    logEvent(document.hidden ? 'Вкладка скрыта' : 'Вкладка снова активна');
  });


  const likes = store.get('zerno-likes', {});
  const likeTimes = [];
  const LIKE_WINDOW = 4000, LIKE_LIMIT = 6, LIKE_COOLDOWN = 3000;
  const likeButtons = document.querySelectorAll('.like');

  function paintLike(btn) {
    const id = btn.dataset.id;
    const n = likes[id] || 0;
    btn.querySelector('.like-count').textContent = n;
    btn.setAttribute('aria-pressed', String(n > 0));
  }
  likeButtons.forEach(paintLike);

  likeButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const now = Date.now();
      likeTimes.push(now);
      while (likeTimes.length && now - likeTimes[0] > LIKE_WINDOW) likeTimes.shift();

      if (likeTimes.length > LIKE_LIMIT) {
        likeButtons.forEach((b) => { b.disabled = true; });
        toast('Ого, сколько любви! Лайки на паузе 3 секунды.', 'warn');
        logEvent('Лайки временно заблокированы (спам)');
        setTimeout(() => {
          likeButtons.forEach((b) => { b.disabled = false; });
          likeTimes.length = 0;
        }, LIKE_COOLDOWN);
        return;
      }

      const id = btn.dataset.id;
      likes[id] = (likes[id] || 0) + 1;
      store.set('zerno-likes', likes);
      paintLike(btn);
      bump('likes');
      btn.classList.add('pop');
      setTimeout(() => btn.classList.remove('pop'), 150);
      if (likes[id] === 10) toast('10 лайков! «' + btn.dataset.title + '» — ваш фаворит.');
    });
  });

  document.querySelectorAll('.product .btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const title = btn.closest('.product').querySelector('h3').textContent;
      bump('cart');
      toast('«' + title + '» добавлено в заказ');
    });
  });

  const toTop = el('button', { class: 'icon-btn to-top', type: 'button', 'aria-label': 'Наверх' }, '↑');
  toTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  document.body.append(toTop);

  render();
})();
